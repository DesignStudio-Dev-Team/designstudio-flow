<?php
/**
 * Plugin Update Checker
 *
 * Handles checking for updates from GitHub releases
 * Supports both public and private repositories
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class DSF_Update_Checker {

	/**
	 * GitHub repository info
	 */
	private $github_username = 'DesignStudio-Dev-Team';
	private $github_repo     = 'designstudio-flow';

	/**
	 * GitHub access token for private repos
	 * Set via: update_option('dsf_github_token', 'your_token_here');
	 */
	private $github_token = null;

	/**
	 * Plugin info
	 */
	private $plugin_slug;
	private $plugin_basename;
	private $current_version;
	private $plugin_update_uri;

	/**
	 * Cache key and duration
	 */
	private $cache_key      = 'dsf_update_check_v2';
	private $cache_duration = 12 * HOUR_IN_SECONDS;
	private $version_option_key = 'dsf_update_checker_version';

	/**
	 * Single instance
	 */
	private static $instance = null;

	/**
	 * Get instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		$this->plugin_slug     = 'designstudio-flow';
		$this->plugin_basename = DSF_PLUGIN_BASENAME;
		$this->current_version = DSF_VERSION;
		$this->plugin_update_uri = 'https://github.com/' . $this->github_username . '/' . $this->github_repo;

		// Load GitHub token: check wp-config constant first, then fallback to option
		if ( defined( 'DSF_GITHUB_TOKEN' ) && DSF_GITHUB_TOKEN ) {
			$this->github_token = DSF_GITHUB_TOKEN;
		} else {
			$this->github_token = get_option( 'dsf_github_token', '' );
		}

		$this->init_hooks();
	}

	/**
	 * Initialize hooks
	 */
	private function init_hooks() {
		// Check for updates
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_updates' ) );

		// Plugin info popup
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );

		// Refresh update state when the installed plugin version changes.
		add_action( 'admin_init', array( $this, 'maybe_refresh_update_state' ) );

		// After update, clear cache
		add_action( 'upgrader_process_complete', array( $this, 'clear_cache' ), 10, 2 );

		// Filter for authenticated downloads (private repos)
		add_filter( 'upgrader_pre_download', array( $this, 'filter_download' ), 10, 3 );

		// Normalize extracted GitHub package folders to the plugin directory name.
		add_filter( 'upgrader_source_selection', array( $this, 'normalize_package_source' ), 10, 4 );
	}

	/**
	 * Check GitHub for updates
	 */
	public function check_for_updates( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		$remote_version = $this->get_remote_version();

		if ( $remote_version && version_compare( $this->current_version, $remote_version->version, '<' ) ) {
			$transient->response[ $this->plugin_basename ] = (object) array(
				'id'           => $this->plugin_update_uri,
				'slug'         => $this->plugin_slug,
				'plugin'       => $this->plugin_basename,
				'new_version'  => $remote_version->version,
				'url'          => $remote_version->url,
				'package'      => $remote_version->download_url,
				'icons'        => array(),
				'banners'      => array(),
				'tested'       => $remote_version->tested ?? '',
				'requires_php' => $remote_version->requires_php ?? '7.4',
			);
		}

		return $transient;
	}

	/**
	 * Plugin info for the popup
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action ) {
			return $result;
		}

		if ( ! isset( $args->slug ) || $this->plugin_slug !== $args->slug ) {
			return $result;
		}

		$remote_version = $this->get_remote_version();

		if ( ! $remote_version ) {
			return $result;
		}

		return (object) array(
			'id'             => $this->plugin_update_uri,
			'name'           => 'DesignStudio Flow',
			'slug'           => $this->plugin_slug,
			'version'        => $remote_version->version,
			'author'         => '<a href="https://designstudio.com">DesignStudio Network, Inc.</a>',
			'author_profile' => 'https://designstudio.com',
			'homepage'       => 'https://designstudio.com/flow',
			'requires'       => '5.8',
			'tested'         => $remote_version->tested ?? '',
			'requires_php'   => $remote_version->requires_php ?? '7.4',
			'downloaded'     => 0,
			'last_updated'   => $remote_version->last_updated ?? '',
			'sections'       => array(
				'description'  => 'Build your WordPress Page with Artisanal Content Blocks.',
				'changelog'    => $remote_version->changelog ?? '',
				'installation' => 'Upload the plugin zip file via WordPress admin and activate.',
			),
			'download_link'  => $remote_version->download_url,
		);
	}

	/**
	 * Get remote version info from GitHub
	 */
	private function get_remote_version() {
		$cached = get_transient( $this->cache_key );

		if ( false !== $cached ) {
			return $cached;
		}

		// Build request headers
		$headers = array(
			'Accept'     => 'application/vnd.github.v3+json',
			'User-Agent' => 'WordPress/' . get_bloginfo( 'version' ),
		);

		// Add authorization header for private repos
		if ( ! empty( $this->github_token ) ) {
			$headers['Authorization'] = 'Bearer ' . $this->github_token;
		}

		$release_version = $this->get_latest_release_version( $headers );
		$tag_version     = $this->get_latest_tag_version( $headers );

		if ( $release_version && ( ! $tag_version || version_compare( $release_version->version, $tag_version->version, '>=' ) ) ) {
			$version_data = $release_version;
		} else {
			$version_data = $tag_version;
		}

		if ( ! $version_data ) {
			return false;
		}

		set_transient( $this->cache_key, $version_data, $this->cache_duration );

		return $version_data;
	}

	/**
	 * Get latest published GitHub release metadata.
	 *
	 * @param array $headers Request headers.
	 * @return object|false
	 */
	private function get_latest_release_version( $headers ) {
		$response = wp_remote_get(
			"https://api.github.com/repos/{$this->github_username}/{$this->github_repo}/releases/latest",
			array(
				'timeout' => 10,
				'headers' => $headers,
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$release = json_decode( wp_remote_retrieve_body( $response ) );

		if ( empty( $release->tag_name ) ) {
			return false;
		}

		// Find the best release ZIP asset.
		$download_url = '';
		if ( ! empty( $release->assets ) ) {
			$preferred_asset = 'designstudio-flow-' . ltrim( $release->tag_name, 'v' ) . '.zip';

			foreach ( $release->assets as $asset ) {
				if ( empty( $asset->name ) || '.zip' !== strtolower( substr( $asset->name, -4 ) ) ) {
					continue;
				}

				if ( $asset->name === $preferred_asset || 0 === strpos( $asset->name, $this->plugin_slug . '-' ) ) {
					$download_url = ! empty( $this->github_token ) ? $asset->url : $asset->browser_download_url;
					break;
				}
			}
		}

		if ( empty( $download_url ) ) {
			$download_url = $release->zipball_url;
		}

		return (object) array(
			'version'      => ltrim( $release->tag_name, 'v' ),
			'download_url' => $download_url,
			'url'          => $release->html_url,
			'changelog'    => $release->body ?? '',
			'last_updated' => $release->published_at ?? '',
			'tested'       => '',
			'requires_php' => '7.4',
		);
	}

	/**
	 * Get the highest semver GitHub tag when a formal release has not been published yet.
	 *
	 * @param array $headers Request headers.
	 * @return object|false
	 */
	private function get_latest_tag_version( $headers ) {
		$response = wp_remote_get(
			"https://api.github.com/repos/{$this->github_username}/{$this->github_repo}/tags?per_page=20",
			array(
				'timeout' => 10,
				'headers' => $headers,
			)
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}

		$tags = json_decode( wp_remote_retrieve_body( $response ) );
		if ( empty( $tags ) || ! is_array( $tags ) ) {
			return false;
		}

		$latest_tag = false;

		foreach ( $tags as $tag ) {
			if ( empty( $tag->name ) ) {
				continue;
			}

			$version = ltrim( $tag->name, 'v' );
			if ( ! preg_match( '/^\d+(?:\.\d+)+$/', $version ) ) {
				continue;
			}

			$tag_data = (object) array(
				'version'      => $version,
				'download_url' => $this->get_tag_download_url( $tag->name ),
				'url'          => "https://github.com/{$this->github_username}/{$this->github_repo}/releases/tag/{$tag->name}",
				'changelog'    => '',
				'last_updated' => '',
				'tested'       => '',
				'requires_php' => '7.4',
			);

			if ( ! $latest_tag || version_compare( $latest_tag->version, $tag_data->version, '<' ) ) {
				$latest_tag = $tag_data;
			}
		}

		return $latest_tag;
	}

	/**
	 * Build a downloadable ZIP URL from a Git tag.
	 *
	 * @param string $tag_name Git tag name.
	 * @return string
	 */
	private function get_tag_download_url( $tag_name ) {
		if ( ! empty( $this->github_token ) ) {
			return "https://api.github.com/repos/{$this->github_username}/{$this->github_repo}/zipball/{$tag_name}";
		}

		return "https://github.com/{$this->github_username}/{$this->github_repo}/archive/refs/tags/{$tag_name}.zip";
	}

	/**
	 * Filter download to add authentication for private repos
	 */
	public function filter_download( $reply, $package, $upgrader ) {
		unset( $upgrader );
		// Only handle our plugin's downloads
		if ( false === strpos( $package, $this->github_repo ) ) {
			return $reply;
		}

		// Only needed for private repos with a token
		if ( empty( $this->github_token ) ) {
			return $reply;
		}

		// Download with authentication
		$response = wp_remote_get(
			$package,
			array(
				'timeout' => 300,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->github_token,
					'Accept'        => 'application/octet-stream',
					'User-Agent'    => 'WordPress/' . get_bloginfo( 'version' ),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'download_failed', $response->get_error_message() );
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'download_failed', 'Failed to download plugin update.' );
		}

		// Save to temp file
		$temp_file = wp_tempnam( $package );
		require_once ABSPATH . 'wp-admin/includes/file.php';
		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			WP_Filesystem();
		}

		if ( ! $wp_filesystem ) {
			return new WP_Error( 'download_failed', 'File system unavailable.' );
		}

		$written = $wp_filesystem->put_contents( $temp_file, wp_remote_retrieve_body( $response ), FS_CHMOD_FILE );
		if ( ! $written ) {
			return new WP_Error( 'download_failed', 'Failed to write update package.' );
		}

		return $temp_file;
	}

	/**
	 * Normalize extracted GitHub package folders so WordPress upgrades in place.
	 *
	 * GitHub zipballs unzip to repo-name-hash folders, which do not match the
	 * installed plugin directory. WordPress expects the source folder name to
	 * match the existing plugin directory during upgrades.
	 *
	 * @param string      $source        Source file source location.
	 * @param string      $remote_source Remote file source location.
	 * @param WP_Upgrader $upgrader      Upgrader instance.
	 * @param array       $hook_extra    Extra upgrader context.
	 * @return string|WP_Error
	 */
	public function normalize_package_source( $source, $remote_source, $upgrader, $hook_extra ) {
		unset( $upgrader );

		if ( ! $this->is_our_plugin_update( $hook_extra ) ) {
			return $source;
		}

		$normalized_source = untrailingslashit( $source );
		$expected_source   = trailingslashit( $remote_source ) . $this->plugin_slug;

		if ( $normalized_source === untrailingslashit( $expected_source ) ) {
			return $source;
		}

		$plugin_file = trailingslashit( $normalized_source ) . 'designstudio-flow.php';
		if ( ! file_exists( $plugin_file ) ) {
			return $source;
		}

		global $wp_filesystem;

		if ( ! $wp_filesystem ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			WP_Filesystem();
		}

		if ( ! $wp_filesystem ) {
			return new WP_Error( 'dsf_update_fs_unavailable', 'Could not access the WordPress filesystem during update.' );
		}

		if ( $wp_filesystem->exists( $expected_source ) && ! $wp_filesystem->delete( $expected_source, true ) ) {
			return new WP_Error( 'dsf_update_source_conflict', 'Could not prepare the plugin update directory.' );
		}

		if ( ! $wp_filesystem->move( $normalized_source, $expected_source, true ) ) {
			return new WP_Error( 'dsf_update_source_move_failed', 'Could not normalize the plugin update package.' );
		}

		return $expected_source;
	}

	/**
	 * Clear cache after update
	 */
	public function clear_cache( $upgrader, $options ) {
		unset( $upgrader );
		if ( isset( $options['action'], $options['type'] ) && 'update' === $options['action'] && 'plugin' === $options['type'] ) {
			delete_transient( $this->cache_key );
			delete_site_transient( 'update_plugins' );
		}
	}

	/**
	 * Clear cached updater state whenever the installed plugin version changes.
	 *
	 * @return void
	 */
	public function maybe_refresh_update_state() {
		$stored_version = get_option( $this->version_option_key, '' );

		if ( $stored_version === $this->current_version ) {
			return;
		}

		delete_transient( $this->cache_key );
		delete_site_transient( 'update_plugins' );
		update_option( $this->version_option_key, $this->current_version, false );
	}

	/**
	 * Check whether the current upgrader context is for this plugin.
	 *
	 * @param array $hook_extra Extra upgrader context.
	 * @return bool
	 */
	private function is_our_plugin_update( $hook_extra ) {
		if ( empty( $hook_extra['type'] ) || 'plugin' !== $hook_extra['type'] ) {
			return false;
		}

		if ( ! empty( $hook_extra['plugin'] ) ) {
			return $hook_extra['plugin'] === $this->plugin_basename;
		}

		if ( ! empty( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ) {
			return in_array( $this->plugin_basename, $hook_extra['plugins'], true );
		}

		return false;
	}
}

// Initialize (only run if main plugin constants are defined)
if ( defined( 'DSF_VERSION' ) && defined( 'DSF_PLUGIN_BASENAME' ) ) {
	DSF_Update_Checker::get_instance();
}
